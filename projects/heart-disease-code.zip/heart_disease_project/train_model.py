import pandas as pd
from sklearn.linear_model import LogisticRegression
import pickle

# Load dataset
data = pd.read_csv("heart.csv")

# Features and Target
X = data.drop("target", axis=1)
y = data["target"]

# Train model
model = LogisticRegression(max_iter=1000)
model.fit(X, y)

# Save model
pickle.dump(model, open("heart_model.pkl", "wb"))

print("Model Saved Successfully!")