import streamlit as st
import pandas as pd
import pickle

# Page Settings
st.set_page_config(
    page_title="Heart Disease Prediction",
    page_icon="❤️",
    layout="wide")

st.title("❤️ Heart Disease Prediction Using Machine Learning")

# Load Model
model = pickle.load(open("heart_model.pkl", "rb"))

st.write("Enter Patient Details")

col1, col2 = st.columns(2)

with col1:
    age = st.number_input("Age", 20, 100, 35)
    sex = st.selectbox("Sex", ["Female", "Male"])
    cp = st.selectbox("Chest Pain Type", [0,1,2,3])
    trestbps = st.number_input("Resting Blood Pressure", 80, 250, 120)
    chol = st.number_input("Cholesterol", 100, 600, 200)
    fbs = st.selectbox("Fasting Blood Sugar >120 mg/dl", [0,1])

with col2:
    restecg = st.selectbox("Resting ECG", [0,1,2])
    thalach = st.number_input("Maximum Heart Rate", 60, 220, 150)
    exang = st.selectbox("Exercise Induced Angina", [0,1])
    oldpeak = st.number_input("Old Peak", 0.0, 6.0, 1.0)
    slope = st.selectbox("Slope", [0,1,2])
    ca = st.selectbox("Major Vessels", [0,1,2,3,4])
    thal = st.selectbox("Thal", [0,1,2,3])
sex = 1 if sex == "Male" else 0


if st.button("Predict Heart Disease"):

    input_data = [[
        age,
        sex,
        cp,
        trestbps,
        chol,
        fbs,
        restecg,
        thalach,
        exang,
        oldpeak,
        slope,
        ca,
        thal
    ]]

    prediction = model.predict(input_data)

    if prediction[0] == 1:
        st.error("⚠️ High Risk: Heart Disease Detected")
    else:
        st.success("✅ Low Risk: No Heart Disease Detected")

    st.subheader("Entered Patient Details")

    df = pd.DataFrame(input_data, columns=[
        "Age", "Sex", "Chest Pain", "BP", "Cholesterol",
        "FBS", "ECG", "Max Heart Rate", "Exercise Angina",
        "Old Peak", "Slope", "Major Vessels", "Thal"
    ])

    st.dataframe(df)


# -------------------------------
# Dataset Preview
# -------------------------------
st.markdown("---")
st.subheader("📊 Dataset Preview")

try:
    data = pd.read_csv("heart2.csv")
    st.dataframe(data.head())

    st.write("Dataset Shape:", data.shape)

    st.subheader("Target Distribution")
    st.bar_chart(data["target"].value_counts())

except Exception as e:
    st.warning(f"Dataset not found: {e}")

# -------------------------------
# Footer
# -------------------------------
st.markdown("---")
st.markdown(
    "<center><h4>❤️ Heart Disease Prediction Using Machine Learning</h4>"
    "<p>Developed by Radhika Chaurasiya</p></center>",
    unsafe_allow_html=True
)
