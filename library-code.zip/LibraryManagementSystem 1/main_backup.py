import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3


# ==================================================
# DATABASE
# ==================================================

def connect_db():
    return sqlite3.connect("library.db")


def create_tables():
    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS books (
            book_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            author TEXT NOT NULL,
            category TEXT NOT NULL,
            quantity INTEGER NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS members (
            member_id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            course TEXT NOT NULL,
            contact TEXT NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS issues (
            issue_id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_id INTEGER NOT NULL,
            member_id INTEGER NOT NULL,
            issue_date TEXT NOT NULL,
            return_date TEXT
        )
    """)

    conn.commit()
    conn.close()


# ==================================================
# CLEAR CONTENT AREA
# ==================================================

def clear_content():
    for widget in content_frame.winfo_children():
        widget.destroy()


# ==================================================
# DASHBOARD
# ==================================================

def dashboard():
    clear_content()

    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM books")
    total_books = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM members")
    total_members = cursor.fetchone()[0]

    cursor.execute("""
        SELECT COUNT(*) FROM issues
        WHERE return_date IS NULL
    """)
    issued_books = cursor.fetchone()[0]

    cursor.execute("""
        SELECT COUNT(*) FROM issues
        WHERE return_date IS NOT NULL
    """)
    returned_books = cursor.fetchone()[0]

    conn.close()

    tk.Label(
        content_frame,
        text="WELCOME TO LIBRARY DASHBOARD",
        font=("Arial", 24, "bold"),
        bg="white"
    ).pack(pady=40)

    tk.Label(
        content_frame,
        text="Manage your library books, members and transactions easily.",
        font=("Arial", 12),
        bg="white"
    ).pack(pady=5)

    cards_frame = tk.Frame(content_frame, bg="white")
    cards_frame.pack(pady=50)

    data = [
        ("TOTAL BOOKS", total_books),
        ("TOTAL MEMBERS", total_members),
        ("ISSUED BOOKS", issued_books),
        ("RETURNED BOOKS", returned_books)
    ]

    for i, (text, number) in enumerate(data):
        card = tk.Frame(
            cards_frame,
            bg="#e8f0fe",
            width=180,
            height=130,
            bd=1,
            relief="solid"
        )

        card.grid(row=0, column=i, padx=10)
        card.pack_propagate(False)

        tk.Label(
            card,
            text=str(number),
            font=("Arial", 28, "bold"),
            bg="#e8f0fe"
        ).pack(pady=(25, 5))

        tk.Label(
            card,
            text=text,
            font=("Arial", 10, "bold"),
            bg="#e8f0fe"
        ).pack()


# ==================================================
# ADD BOOK
# ==================================================

def add_book():
    clear_content()

    tk.Label(
        content_frame,
        text="ADD NEW BOOK",
        font=("Arial", 24, "bold"),
        bg="white"
    ).pack(pady=25)

    form = tk.Frame(content_frame, bg="white")
    form.pack()

    labels = ["Book ID", "Book Title", "Author", "Category", "Quantity"]
    entries = []

    for i, text in enumerate(labels):
        tk.Label(
            form,
            text=text,
            font=("Arial", 12),
            bg="white"
        ).grid(row=i, column=0, padx=15, pady=10, sticky="w")

        entry = tk.Entry(
            form,
            width=35,
            font=("Arial", 11)
        )
        entry.grid(row=i, column=1, padx=15, pady=10)
        entries.append(entry)

    def save_book():
        try:
            book_id = int(entries[0].get())
            title = entries[1].get().strip()
            author = entries[2].get().strip()
            category = entries[3].get().strip()
            quantity = int(entries[4].get())

            if not title or not author or not category:
                messagebox.showwarning(
                    "Warning",
                    "Please fill all fields."
                )
                return

            if quantity <= 0:
                messagebox.showwarning(
                    "Warning",
                    "Quantity must be greater than 0."
                )
                return

            conn = connect_db()
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO books
                (book_id, title, author, category, quantity)
                VALUES (?, ?, ?, ?, ?)
            """, (book_id, title, author, category, quantity))

            conn.commit()
            conn.close()

            messagebox.showinfo(
                "Success",
                "Book added successfully!"
            )

            for entry in entries:
                entry.delete(0, tk.END)

            dashboard()

        except ValueError:
            messagebox.showerror(
                "Error",
                "Book ID and Quantity must be numbers."
            )

        except sqlite3.IntegrityError:
            messagebox.showerror(
                "Error",
                "Book ID already exists."
            )

    tk.Button(
        content_frame,
        text="ADD BOOK",
        command=save_book,
        width=20,
        height=2,
        font=("Arial", 11, "bold"),
        bg="#4CAF50",
        fg="white"
    ).pack(pady=25)


# ==================================================
# VIEW BOOKS
# ==================================================

def view_books():
    clear_content()

    tk.Label(
        content_frame,
        text="ALL BOOKS",
        font=("Arial", 24, "bold"),
        bg="white"
    ).pack(pady=25)

    columns = ("Book ID", "Title", "Author", "Category", "Quantity")

    table = ttk.Treeview(
        content_frame,
        columns=columns,
        show="headings"
    )

    for column in columns:
        table.heading(column, text=column)
        table.column(column, width=140)

    table.pack(
        fill="both",
        expand=True,
        padx=30,
        pady=20
    )

    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM books")
    records = cursor.fetchall()
    conn.close()

    for record in records:
        table.insert("", tk.END, values=record)


# ==================================================
# ADD MEMBER
# ==================================================

def add_member():
    clear_content()

    tk.Label(
        content_frame,
        text="ADD MEMBER",
        font=("Arial", 24, "bold"),
        bg="white"
    ).pack(pady=25)

    form = tk.Frame(content_frame, bg="white")
    form.pack()

    labels = ["Member ID", "Name", "Course", "Contact"]
    entries = []

    for i, text in enumerate(labels):
        tk.Label(
            form,
            text=text,
            font=("Arial", 12),
            bg="white"
        ).grid(row=i, column=0, padx=15, pady=10, sticky="w")

        entry = tk.Entry(
            form,
            width=35,
            font=("Arial", 11)
        )
        entry.grid(row=i, column=1, padx=15, pady=10)
        entries.append(entry)

    def save_member():
        try:
            member_id = int(entries[0].get())
            name = entries[1].get().strip()
            course = entries[2].get().strip()
            contact = entries[3].get().strip()

            if not name or not course or not contact:
                messagebox.showwarning(
                    "Warning",
                    "Please fill all fields."
                )
                return

            conn = connect_db()
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO members
                (member_id, name, course, contact)
                VALUES (?, ?, ?, ?)
            """, (member_id, name, course, contact))

            conn.commit()
            conn.close()

            messagebox.showinfo(
                "Success",
                "Member added successfully!"
            )

            for entry in entries:
                entry.delete(0, tk.END)

            dashboard()

        except ValueError:
            messagebox.showerror(
                "Error",
                "Member ID must be a number."
            )

        except sqlite3.IntegrityError:
            messagebox.showerror(
                "Error",
                "Member ID already exists."
            )

    tk.Button(
        content_frame,
        text="ADD MEMBER",
        command=save_member,
        width=20,
        height=2,
        font=("Arial", 11, "bold"),
        bg="#4CAF50",
        fg="white"
    ).pack(pady=25)


# ==================================================
# VIEW MEMBERS
# ==================================================

def view_members():
    clear_content()

    tk.Label(
        content_frame,
        text="ALL MEMBERS",
        font=("Arial", 24, "bold"),
        bg="white"
    ).pack(pady=25)

    columns = ("Member ID", "Name", "Course", "Contact")

    table = ttk.Treeview(
        content_frame,
        columns=columns,
        show="headings"
    )

    for column in columns:
        table.heading(column, text=column)
        table.column(column, width=170)

    table.pack(
        fill="both",
        expand=True,
        padx=30,
        pady=20
    )

    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM members")
    records = cursor.fetchall()
    conn.close()

    for record in records:
        table.insert("", tk.END, values=record)


# ==================================================
# ISSUE BOOK
# ==================================================

def issue_book():
    clear_content()

    tk.Label(
        content_frame,
        text="ISSUE BOOK",
        font=("Arial", 24, "bold"),
        bg="white"
    ).pack(pady=25)

    form = tk.Frame(content_frame, bg="white")
    form.pack()

    labels = ["Book ID", "Member ID", "Issue Date (DD-MM-YYYY)"]
    entries = []

    for i, text in enumerate(labels):
        tk.Label(
            form,
            text=text,
            font=("Arial", 12),
            bg="white"
        ).grid(row=i, column=0, padx=15, pady=12, sticky="w")

        entry = tk.Entry(
            form,
            width=35,
            font=("Arial", 11)
        )
        entry.grid(row=i, column=1, padx=15, pady=12)
        entries.append(entry)

    def save_issue():
        try:
            book_id = int(entries[0].get())
            member_id = int(entries[1].get())
            issue_date = entries[2].get().strip()

            if not issue_date:
                messagebox.showwarning(
                    "Warning",
                    "Please enter issue date."
                )
                return

            conn = connect_db()
            cursor = conn.cursor()

            cursor.execute(
                "SELECT quantity FROM books WHERE book_id=?",
                (book_id,)
            )
            book = cursor.fetchone()

            if book is None:
                messagebox.showerror("Error", "Book not found.")
                conn.close()
                return

            if book[0] <= 0:
                messagebox.showwarning(
                    "Warning",
                    "Book is not available."
                )
                conn.close()
                return

            cursor.execute(
                "SELECT * FROM members WHERE member_id=?",
                (member_id,)
            )
            member = cursor.fetchone()

            if member is None:
                messagebox.showerror(
                    "Error",
                    "Member not found."
                )
                conn.close()
                return

            cursor.execute("""
                INSERT INTO issues
                (book_id, member_id, issue_date)
                VALUES (?, ?, ?)
            """, (book_id, member_id, issue_date))

            cursor.execute("""
                UPDATE books
                SET quantity = quantity - 1
                WHERE book_id=?
            """, (book_id,))

            conn.commit()
            conn.close()

            messagebox.showinfo(
                "Success",
                "Book issued successfully!"
            )

            dashboard()

        except ValueError:
            messagebox.showerror(
                "Error",
                "Book ID and Member ID must be numbers."
            )

    tk.Button(
        content_frame,
        text="ISSUE BOOK",
        command=save_issue,
        width=20,
        height=2,
        font=("Arial", 11, "bold"),
        bg="#4CAF50",
        fg="white"
    ).pack(pady=25)


# ==================================================
# VIEW ISSUED BOOKS
# ==================================================

def view_issued_books():
    clear_content()

    tk.Label(
        content_frame,
        text="ISSUED BOOKS",
        font=("Arial", 24, "bold"),
        bg="white"
    ).pack(pady=25)

    columns = ("Issue ID", "Book ID", "Member ID", "Issue Date")

    table = ttk.Treeview(
        content_frame,
        columns=columns,
        show="headings"
    )

    for column in columns:
        table.heading(column, text=column)
        table.column(column, width=160)

    table.pack(
        fill="both",
        expand=True,
        padx=30,
        pady=20
    )

    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT issue_id, book_id, member_id, issue_date
        FROM issues
        WHERE return_date IS NULL
    """)

    records = cursor.fetchall()
    conn.close()

    for record in records:
        table.insert("", tk.END, values=record)


# ==================================================
# RETURN BOOK
# ==================================================

def return_book():
    clear_content()

    tk.Label(
        content_frame,
        text="RETURN BOOK",
        font=("Arial", 24, "bold"),
        bg="white"
    ).pack(pady=25)

    form = tk.Frame(content_frame, bg="white")
    form.pack()

    tk.Label(
        form,
        text="Issue ID",
        font=("Arial", 12),
        bg="white"
    ).grid(row=0, column=0, padx=15, pady=12)

    issue_entry = tk.Entry(
        form,
        width=35,
        font=("Arial", 11)
    )
    issue_entry.grid(row=0, column=1, padx=15, pady=12)

    tk.Label(
        form,
        text="Return Date (DD-MM-YYYY)",
        font=("Arial", 12),
        bg="white"
    ).grid(row=1, column=0, padx=15, pady=12)

    date_entry = tk.Entry(
        form,
        width=35,
        font=("Arial", 11)
    )
    date_entry.grid(row=1, column=1, padx=15, pady=12)

    def save_return():
        try:
            issue_id = int(issue_entry.get())
            return_date = date_entry.get().strip()

            if not return_date:
                messagebox.showwarning(
                    "Warning",
                    "Please enter return date."
                )
                return

            conn = connect_db()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT book_id, return_date
                FROM issues
                WHERE issue_id=?
            """, (issue_id,))

            record = cursor.fetchone()

            if record is None:
                messagebox.showerror(
                    "Error",
                    "Issue record not found."
                )
                conn.close()
                return

            if record[1] is not None:
                messagebox.showwarning(
                    "Warning",
                    "This book has already been returned."
                )
                conn.close()
                return

            book_id = record[0]

            cursor.execute("""
                UPDATE issues
                SET return_date=?
                WHERE issue_id=?
            """, (return_date, issue_id))

            cursor.execute("""
                UPDATE books
                SET quantity = quantity + 1
                WHERE book_id=?
            """, (book_id,))

            conn.commit()
            conn.close()

            messagebox.showinfo(
                "Success",
                "Book returned successfully!"
            )

            dashboard()

        except ValueError:
            messagebox.showerror(
                "Error",
                "Issue ID must be a number."
            )

    tk.Button(
        content_frame,
        text="RETURN BOOK",
        command=save_return,
        width=20,
        height=2,
        font=("Arial", 11, "bold"),
        bg="#4CAF50",
        fg="white"
    ).pack(pady=25)


# ==================================================
# VIEW RETURNED BOOKS
# ==================================================

def view_returned_books():
    clear_content()

    tk.Label(
        content_frame,
        text="RETURNED BOOKS",
        font=("Arial", 24, "bold"),
        bg="white"
    ).pack(pady=25)

    columns = (
        "Issue ID",
        "Book ID",
        "Member ID",
        "Issue Date",
        "Return Date"
    )

    table = ttk.Treeview(
        content_frame,
        columns=columns,
        show="headings"
    )

    for column in columns:
        table.heading(column, text=column)
        table.column(column, width=130)

    table.pack(
        fill="both",
        expand=True,
        padx=30,
        pady=20
    )

    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT issue_id, book_id, member_id,
               issue_date, return_date
        FROM issues
        WHERE return_date IS NOT NULL
    """)

    records = cursor.fetchall()
    conn.close()

    for record in records:
        table.insert("", tk.END, values=record)


# ==================================================
# MAIN WINDOW
# ==================================================

create_tables()

root = tk.Tk()
root.title("Library Management System")
root.geometry("1100x700")
root.resizable(False, False)
root.configure(bg="white")


# HEADER

header = tk.Frame(
    root,
    bg="#1f4e78",
    height=80
)
header.pack(fill="x")
header.pack_propagate(False)

tk.Label(
    header,
    text="LIBRARY MANAGEMENT SYSTEM",
    font=("Arial", 25, "bold"),
    bg="#1f4e78",
    fg="white"
).pack(pady=(12, 0))

tk.Label(
    header,
    text="Manage Your Library Easily",
    font=("Arial", 10),
    bg="#1f4e78",
    fg="white"
).pack()


# BODY

body = tk.Frame(root, bg="white")
body.pack(fill="both", expand=True)


# SIDEBAR

sidebar = tk.Frame(
    body,
    bg="#2c3e50",
    width=230
)
sidebar.pack(side="left", fill="y")
sidebar.pack_propagate(False)

tk.Label(
    sidebar,
    text="MENU",
    font=("Arial", 16, "bold"),
    bg="#2c3e50",
    fg="white"
).pack(pady=20)


# CONTENT AREA

content_frame = tk.Frame(
    body,
    bg="white"
)
content_frame.pack(
    side="right",
    fill="both",
    expand=True
)


def menu_button(text, command):
    tk.Button(
        sidebar,
        text=text,
        command=command,
        width=24,
        height=2,
        font=("Arial", 10, "bold"),
        bg="#34495e",
        fg="white",
        activebackground="#4CAF50",
        activeforeground="white",
        bd=0
    ).pack(pady=4)


menu_button("DASHBOARD", dashboard)
menu_button("ADD BOOK", add_book)
menu_button("VIEW BOOKS", view_books)
menu_button("ADD MEMBER", add_member)
menu_button("VIEW MEMBERS", view_members)
menu_button("ISSUE BOOK", issue_book)
menu_button("VIEW ISSUED BOOKS", view_issued_books)
menu_button("RETURN BOOK", return_book)
menu_button("VIEW RETURNED BOOKS", view_returned_books)


# START DASHBOARD

dashboard()

root.mainloop()