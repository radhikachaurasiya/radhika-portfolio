import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3


# ================= DATABASE =================

def connect_db():
    return sqlite3.connect("library.db")


def create_tables():
    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS books (
            book_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            author TEXT NOT NULL,
            category TEXT NOT NULL,
            quantity INTEGER NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS members (
            member_id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            course TEXT NOT NULL,
            contact TEXT NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS issues (
            issue_id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_id INTEGER NOT NULL,
            member_id INTEGER NOT NULL,
            issue_date TEXT NOT NULL,
            return_date TEXT
        )
    """)

    conn.commit()
    conn.close()


# ================= ADD BOOK =================

def add_book():
    win = tk.Toplevel(root)
    win.title("Add Book")
    win.geometry("450x500")

    tk.Label(win, text="ADD NEW BOOK",
             font=("Arial", 20, "bold")).pack(pady=20)

    labels = ["Book ID", "Book Title", "Author", "Category", "Quantity"]
    entries = []

    for text in labels:
        tk.Label(win, text=text).pack()
        entry = tk.Entry(win, width=35)
        entry.pack(pady=5)
        entries.append(entry)

    def save_book():
        try:
            book_id = int(entries[0].get())
            title = entries[1].get().strip()
            author = entries[2].get().strip()
            category = entries[3].get().strip()
            quantity = int(entries[4].get())

            if not title or not author or not category:
                messagebox.showwarning("Warning", "Please fill all fields.")
                return

            if quantity <= 0:
                messagebox.showwarning(
                    "Warning",
                    "Quantity must be greater than 0."
                )
                return

            conn = connect_db()
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO books
                (book_id, title, author, category, quantity)
                VALUES (?, ?, ?, ?, ?)
            """, (book_id, title, author, category, quantity))

            conn.commit()
            conn.close()

            messagebox.showinfo(
                "Success",
                "Book added successfully!"
            )

            for entry in entries:
                entry.delete(0, tk.END)

        except ValueError:
            messagebox.showerror(
                "Error",
                "Book ID and Quantity must be numbers."
            )

        except sqlite3.IntegrityError:
            messagebox.showerror(
                "Error",
                "Book ID already exists."
            )

    tk.Button(
        win,
        text="ADD BOOK",
        command=save_book,
        width=20,
        height=2
    ).pack(pady=20)


# ================= VIEW BOOKS =================

def view_books():
    win = tk.Toplevel(root)
    win.title("View Books")
    win.geometry("850x450")

    tk.Label(
        win,
        text="ALL BOOKS",
        font=("Arial", 20, "bold")
    ).pack(pady=15)

    columns = ("Book ID", "Title", "Author", "Category", "Quantity")

    table = ttk.Treeview(
        win,
        columns=columns,
        show="headings"
    )

    for column in columns:
        table.heading(column, text=column)
        table.column(column, width=150)

    table.pack(
        fill="both",
        expand=True,
        padx=20,
        pady=20
    )

    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM books")
    records = cursor.fetchall()

    conn.close()

    for record in records:
        table.insert("", tk.END, values=record)


# ================= ADD MEMBER =================

def add_member():
    win = tk.Toplevel(root)
    win.title("Add Member")
    win.geometry("450x450")

    tk.Label(
        win,
        text="ADD MEMBER",
        font=("Arial", 20, "bold")
    ).pack(pady=20)

    labels = ["Member ID", "Name", "Course", "Contact"]
    entries = []

    for text in labels:
        tk.Label(win, text=text).pack()
        entry = tk.Entry(win, width=35)
        entry.pack(pady=5)
        entries.append(entry)

    def save_member():
        try:
            member_id = int(entries[0].get())
            name = entries[1].get().strip()
            course = entries[2].get().strip()
            contact = entries[3].get().strip()

            if not name or not course or not contact:
                messagebox.showwarning(
                    "Warning",
                    "Please fill all fields."
                )
                return

            conn = connect_db()
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO members
                (member_id, name, course, contact)
                VALUES (?, ?, ?, ?)
            """, (member_id, name, course, contact))

            conn.commit()
            conn.close()

            messagebox.showinfo(
                "Success",
                "Member added successfully!"
            )

            for entry in entries:
                entry.delete(0, tk.END)

        except ValueError:
            messagebox.showerror(
                "Error",
                "Member ID must be a number."
            )

        except sqlite3.IntegrityError:
            messagebox.showerror(
                "Error",
                "Member ID already exists."
            )

    tk.Button(
        win,
        text="ADD MEMBER",
        command=save_member,
        width=20,
        height=2
    ).pack(pady=20)


# ================= VIEW MEMBERS =================

def view_members():
    win = tk.Toplevel(root)
    win.title("View Members")
    win.geometry("750x450")

    tk.Label(
        win,
        text="ALL MEMBERS",
        font=("Arial", 20, "bold")
    ).pack(pady=15)

    columns = ("Member ID", "Name", "Course", "Contact")

    table = ttk.Treeview(
        win,
        columns=columns,
        show="headings"
    )

    for column in columns:
        table.heading(column, text=column)
        table.column(column, width=170)

    table.pack(
        fill="both",
        expand=True,
        padx=20,
        pady=20
    )

    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM members")
    records = cursor.fetchall()

    conn.close()

    for record in records:
        table.insert("", tk.END, values=record)


# ================= ISSUE BOOK =================

def issue_book():
    win = tk.Toplevel(root)
    win.title("Issue Book")
    win.geometry("450x380")

    tk.Label(
        win,
        text="ISSUE BOOK",
        font=("Arial", 20, "bold")
    ).pack(pady=20)

    tk.Label(win, text="Book ID").pack()
    book_entry = tk.Entry(win, width=35)
    book_entry.pack(pady=5)

    tk.Label(win, text="Member ID").pack()
    member_entry = tk.Entry(win, width=35)
    member_entry.pack(pady=5)

    tk.Label(win, text="Issue Date (DD-MM-YYYY)").pack()
    date_entry = tk.Entry(win, width=35)
    date_entry.pack(pady=5)

    def save_issue():
        try:
            book_id = int(book_entry.get())
            member_id = int(member_entry.get())
            issue_date = date_entry.get().strip()

            if not issue_date:
                messagebox.showwarning(
                    "Warning",
                    "Please enter issue date."
                )
                return

            conn = connect_db()
            cursor = conn.cursor()

            cursor.execute(
                "SELECT quantity FROM books WHERE book_id=?",
                (book_id,)
            )

            book = cursor.fetchone()

            if book is None:
                messagebox.showerror(
                    "Error",
                    "Book not found."
                )
                conn.close()
                return

            if book[0] <= 0:
                messagebox.showwarning(
                    "Warning",
                    "Book is not available."
                )
                conn.close()
                return

            cursor.execute(
                "SELECT * FROM members WHERE member_id=?",
                (member_id,)
            )

            member = cursor.fetchone()

            if member is None:
                messagebox.showerror(
                    "Error",
                    "Member not found."
                )
                conn.close()
                return

            cursor.execute("""
                INSERT INTO issues
                (book_id, member_id, issue_date)
                VALUES (?, ?, ?)
            """, (book_id, member_id, issue_date))

            cursor.execute("""
                UPDATE books
                SET quantity = quantity - 1
                WHERE book_id=?
            """, (book_id,))

            conn.commit()
            conn.close()

            messagebox.showinfo(
                "Success",
                "Book issued successfully!"
            )

            book_entry.delete(0, tk.END)
            member_entry.delete(0, tk.END)
            date_entry.delete(0, tk.END)

        except ValueError:
            messagebox.showerror(
                "Error",
                "Book ID and Member ID must be numbers."
            )

    tk.Button(
        win,
        text="ISSUE BOOK",
        command=save_issue,
        width=20,
        height=2
    ).pack(pady=20)


# ================= VIEW ISSUED BOOKS =================

def view_issued_books():
    win = tk.Toplevel(root)
    win.title("View Issued Books")
    win.geometry("850x450")

    tk.Label(
        win,
        text="ISSUED BOOKS",
        font=("Arial", 20, "bold")
    ).pack(pady=15)

    columns = (
        "Issue ID",
        "Book ID",
        "Member ID",
        "Issue Date"
    )

    table = ttk.Treeview(
        win,
        columns=columns,
        show="headings"
    )

    for column in columns:
        table.heading(column, text=column)
        table.column(column, width=180)

    table.pack(
        fill="both",
        expand=True,
        padx=20,
        pady=20
    )

    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT issue_id, book_id, member_id, issue_date
        FROM issues
        WHERE return_date IS NULL
    """)

    records = cursor.fetchall()
    conn.close()

    for record in records:
        table.insert("", tk.END, values=record)


# ================= RETURN BOOK =================

def return_book():
    win = tk.Toplevel(root)
    win.title("Return Book")
    win.geometry("450x320")

    tk.Label(
        win,
        text="RETURN BOOK",
        font=("Arial", 20, "bold")
    ).pack(pady=20)

    tk.Label(win, text="Issue ID").pack()

    issue_entry = tk.Entry(win, width=35)
    issue_entry.pack(pady=8)

    tk.Label(win, text="Return Date (DD-MM-YYYY)").pack()

    date_entry = tk.Entry(win, width=35)
    date_entry.pack(pady=8)

    def save_return():
        try:
            issue_id = int(issue_entry.get())
            return_date = date_entry.get().strip()

            if not return_date:
                messagebox.showwarning(
                    "Warning",
                    "Please enter return date."
                )
                return

            conn = connect_db()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT book_id, return_date
                FROM issues
                WHERE issue_id=?
            """, (issue_id,))

            record = cursor.fetchone()

            if record is None:
                messagebox.showerror(
                    "Error",
                    "Issue record not found."
                )
                conn.close()
                return

            if record[1] is not None:
                messagebox.showwarning(
                    "Warning",
                    "This book has already been returned."
                )
                conn.close()
                return

            book_id = record[0]

            cursor.execute("""
                UPDATE issues
                SET return_date=?
                WHERE issue_id=?
            """, (return_date, issue_id))

            cursor.execute("""
                UPDATE books
                SET quantity = quantity + 1
                WHERE book_id=?
            """, (book_id,))

            conn.commit()
            conn.close()

            messagebox.showinfo(
                "Success",
                "Book returned successfully!"
            )

            issue_entry.delete(0, tk.END)
            date_entry.delete(0, tk.END)

        except ValueError:
            messagebox.showerror(
                "Error",
                "Issue ID must be a number."
            )

    tk.Button(
        win,
        text="RETURN BOOK",
        command=save_return,
        width=20,
        height=2
    ).pack(pady=20)


# ================= VIEW RETURNED BOOKS =================

def view_returned_books():
    win = tk.Toplevel(root)
    win.title("View Returned Books")
    win.geometry("900x450")

    tk.Label(
        win,
        text="RETURNED BOOKS",
        font=("Arial", 20, "bold")
    ).pack(pady=15)

    columns = (
        "Issue ID",
        "Book ID",
        "Member ID",
        "Issue Date",
        "Return Date"
    )

    table = ttk.Treeview(
        win,
        columns=columns,
        show="headings"
    )

    for column in columns:
        table.heading(column, text=column)
        table.column(column, width=160)

    table.pack(
        fill="both",
        expand=True,
        padx=20,
        pady=20
    )

    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT issue_id, book_id, member_id,
               issue_date, return_date
        FROM issues
        WHERE return_date IS NOT NULL
    """)

    records = cursor.fetchall()
    conn.close()

    for record in records:
        table.insert("", tk.END, values=record)


# ================= MAIN WINDOW =================

create_tables()

root = tk.Tk()
root.title("Library Management System")
root.geometry("900x700")
root.resizable(False, False)

tk.Label(
    root,
    text="LIBRARY MANAGEMENT SYSTEM",
    font=("Arial", 26, "bold")
).pack(pady=30)


buttons = [
    ("ADD BOOK", add_book),
    ("VIEW BOOKS", view_books),
    ("ADD MEMBER", add_member),
    ("VIEW MEMBERS", view_members),
    ("ISSUE BOOK", issue_book),
    ("VIEW ISSUED BOOKS", view_issued_books),
    ("RETURN BOOK", return_book),
    ("VIEW RETURNED BOOKS", view_returned_books)
]

for text, command in buttons:
    tk.Button(
        root,
        text=text,
        command=command,
        width=28,
        height=2,
        font=("Arial", 11, "bold")
    ).pack(pady=5)


root.mainloop()